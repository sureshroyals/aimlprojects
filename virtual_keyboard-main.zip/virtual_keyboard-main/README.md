# virtual_keyboard

This project is about using openCV and mediapipe libraries   to utilize the webcamera for writing in real time.   
The main idea is:   
* detect hands using mediapipe
* detect index and thumb fingers' tip locations
* if only index is over one of the keys change the transparency of the key
* if both index and thumb fingers are over a key add the letter of the key to the written text      
to watch the demo of the program press [here](https://youtu.be/lFWwknlw2z0)